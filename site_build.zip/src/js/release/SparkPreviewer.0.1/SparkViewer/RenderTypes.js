console.log("RenderTypes.js included");

function RenderVertex() {
 this.position;  // Vector3
 this.normal;    // Vector3
 this.uv;        // Vector2

 return this;
}



