﻿console.log("Camera.js included");

function Camera() {
    var mProjectionMatrix;
    var mViewMatrix;
    
    this.rotate
};